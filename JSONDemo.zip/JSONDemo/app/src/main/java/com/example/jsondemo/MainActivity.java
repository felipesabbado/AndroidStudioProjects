package com.example.jsondemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    ImageView image;
    JSONObject objUsTu = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image = findViewById(R.id.imageView);

        DownloadTask task = new DownloadTask();
        try {
            objUsTu = task.execute("https://ulide.herokuapp.com/api/userAchievements/1").get();
        } catch (ExecutionException e) {
            e.printStackTrace();
            objUsTu = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
            objUsTu = null;
        }
    }

    public void getWeather(View view)
    {
        if(objUsTu != null)
        {
            for(int i = 0; i< objUsTu.length(); i++)
            {
                try {

                    switch (objUsTu.getString("usName")){
                        case "Teobaldo Mata":
                            image.setImageResource(R.drawable.ic_thunderstorm);
                            break;
                        case "Nivel 2":
                            image.setImageResource(R.drawable.ic_drizzle);
                            break;
                        case "Rain":
                            image.setImageResource(R.drawable.ic_rain);
                            break;
                        case "Snow":
                            image.setImageResource(R.drawable.ic_snow);
                            break;
                        case "Clear":
                            image.setImageResource(R.drawable.ic_clear);
                            break;
                        case "Clouds":
                            image.setImageResource(R.drawable.ic_cloud);
                            break;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
