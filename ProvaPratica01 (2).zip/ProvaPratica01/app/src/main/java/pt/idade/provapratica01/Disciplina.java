package pt.idade.provapratica01;

import java.util.ArrayList;

public class Disciplina {
    private String nome;
    private ArrayList<Aluno> alunos = new ArrayList<>();

    public Disciplina(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public int getSizeAluno(){
        return this.alunos.size();
    }

    public String getNomeAluno(int n){
        return this.alunos.get(n).getNome();
    }

    public boolean getPresAluno(int n1, int n2) {
        return this.alunos.get(n1).getPresencas(n2);
    }

    public int getIdade(int n){
        return this.alunos.get(n).getIdade();
    }

    public void setAlunos(String nome, int numero, int idade) {
        Aluno aluno = new Aluno(nome, numero, idade);
        this.alunos.add(aluno);
    }

    public void removeAlunos(Aluno aluno) {
        this.alunos.remove(aluno);
    }

    public int numAlunos() {
        return this.alunos.size();
    }

    public double perPres(int n) {
        double assid = 0;

        for (int j = 0; j < alunos.get(n).getLengthPresenca(); j++){
            if (alunos.get(j).getPresencas(j)){
                assid++;
            }
        }
            return (14/assid) * 100;
    }
}
