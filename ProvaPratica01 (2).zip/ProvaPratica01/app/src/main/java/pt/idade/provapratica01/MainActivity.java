package pt.idade.provapratica01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText et_nomeAluno;
    EditText et_numAluno;
    EditText et_idadeAluno;
    Disciplina uc1 = new Disciplina("Dispositivos Móveis");



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_nomeAluno = findViewById(R.id.et_nomeAluno);
        et_numAluno = findViewById(R.id.et_numAluno);
        et_idadeAluno = findViewById(R.id.et_idadeAluno);
    }

    public void inserir(View view){
        String nome = et_nomeAluno.getText().toString();
        int numero = Integer.parseInt(et_numAluno.getText().toString());
        int idade = Integer.parseInt(et_idadeAluno.getText().toString());
        uc1.setAlunos(nome, numero, idade);
    }

    public void qtsAlunos(View view){
        int numAlunos = uc1.numAlunos();
        Toast.makeText(this, "Há " + numAlunos + " na UC " + uc1.getNome(), Toast.LENGTH_SHORT).show();
    }

    public void velho(View view){
        int c = 0;
        String nome = "";
        for (int i = 0; i < uc1.numAlunos(); i++){
            if (uc1.getIdade(i) > c) {
                c = uc1.getIdade(i);
            }
        }
        for (int i = 0; i < uc1.numAlunos(); i++){
            if (uc1.getIdade(i) == c) {
                nome = uc1.getNomeAluno(i);
                break;
            }
        }
        Toast.makeText(this, "O aluno mais velho é " + nome, Toast.LENGTH_SHORT).show();
    }

    public void assiduidade(View view){
        String alunoMais = "";
        String alunoMenos = "";
        double mais = 0;
        double menos = 0;

        for (int i = 0; i < uc1.numAlunos(); i++){
            if (uc1.perPres(i) > mais) {
                mais = uc1.perPres(i);
            } else {
                menos = uc1.perPres(i);
            }
        }
    }
}